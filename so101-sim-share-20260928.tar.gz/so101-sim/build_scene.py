"""Build a local scene without changing the pinned upstream robot files."""

import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np

ROOT = Path(__file__).resolve().parent
MODEL_DIR = ROOT / "vendor/SO-ARM100/Simulation/SO101"
SCENE_PATH = ROOT / "generated/scene.xml"


def numbers(values):
    return " ".join(f"{value:.10g}" for value in values)


def vertical_fov(camera):
    angle = float(camera["fov_deg"])
    width, height = camera["width"], camera["height"]
    if not 0 < angle < 180 or min(width, height) <= 0:
        raise ValueError("Camera dimensions and FOV must be positive; FOV must be < 180.")
    factors = {
        "vertical": 1,
        "horizontal": height / width,
        "diagonal": height / math.hypot(width, height),
    }
    return math.degrees(2 * math.atan(math.tan(math.radians(angle) / 2) * factors[camera["fov_axis"]]))


def look_axes(position, target):
    backward = np.array(position, dtype=float) - target
    backward /= np.linalg.norm(backward)
    right = np.cross([0, 0, 1], backward)
    right /= np.linalg.norm(right)
    return numbers(np.r_[right, np.cross(backward, right)])


def build_scene():
    settings = json.loads((ROOT / "settings.json").read_text())
    source = MODEL_DIR / "so101_new_calib_camera.xml"
    if not source.is_file():
        raise FileNotFoundError(f"Official model not found: {source}. See README.md.")
    tree = ET.parse(source)
    root = tree.getroot()
    root.set("model", "SO-101 practice scene")
    root.find("compiler").set("meshdir", str(MODEL_DIR / "assets"))
    ET.SubElement(root, "option", timestep=str(settings["timestep_s"]), integrator="implicitfast")
    visual = ET.SubElement(root, "visual")
    camera = settings["camera"]
    ET.SubElement(visual, "global", offwidth=str(camera["width"]), offheight=str(camera["height"]))
    ET.SubElement(visual, "headlight", diffuse="0.4 0.4 0.4", ambient="0.2 0.2 0.2", specular="0.1 0.1 0.1")
    ET.SubElement(visual, "quality", shadowsize="1024", offsamples="0")
    ET.SubElement(visual, "map", znear="0.001")
    ET.SubElement(root, "statistic", center="0.2 0 0.13", extent="0.85")

    camera_body = root.find(f".//body[@name='{camera['parent_body']}']")
    if camera_body is None:
        raise ValueError(f"Unknown camera parent: {camera['parent_body']}")
    # Mesh lens projects along local +Z; MuJoCo cameras look along local -Z.
    ET.SubElement(camera_body, "camera", name=camera["name"], mode="fixed",
                  pos=numbers(camera["position_m"]), xyaxes=numbers(camera["xyaxes"]),
                  fovy=str(vertical_fov(camera)))

    assets = root.find("asset")
    ET.SubElement(assets, "texture", name="table_grid", type="2d", builtin="checker",
                  rgb1="0.46 0.49 0.48", rgb2="0.36 0.39 0.38", width="512", height="512")
    ET.SubElement(assets, "material", name="table", texture="table_grid", texrepeat="10 10",
                  texuniform="true", reflectance="0.03")
    world = root.find("worldbody")
    ET.SubElement(world, "light", pos="0.2 -0.3 1.5", dir="0 0 -1", directional="true",
                  diffuse="0.45 0.45 0.45", specular="0.1 0.1 0.1")
    ET.SubElement(world, "geom", name="work_surface", type="plane", pos="0 0 -0.0024",
                  size="1 1 0.02", material="table", friction="0.8 0.01 0.001")
    pos, target = [0.8, -0.8, 0.65], [0.20, 0, 0.13]
    ET.SubElement(world, "camera", name="overview", pos=numbers(pos),
                  xyaxes=look_axes(pos, target), fovy="40")
    for name, pos, color in [
        ("red_block", [0.30, 0, 0.013], "0.85 0.12 0.16 1"),
        ("green_block", [0.34, 0.06, 0.013], "0.12 0.60 0.32 1"),
        ("blue_block", [0.29, -0.065, 0.013], "0.10 0.38 0.85 1"),
    ]:
        body = ET.SubElement(world, "body", name=name, pos=numbers(pos))
        ET.SubElement(body, "freejoint", name=f"{name}_free")
        ET.SubElement(body, "geom", name=f"{name}_geom", type="box", size="0.015 0.015 0.015",
                      mass="0.02", rgba=color, friction="0.8 0.01 0.001", condim="4")

    SCENE_PATH.parent.mkdir(exist_ok=True)
    ET.indent(tree, space="  ")
    tree.write(SCENE_PATH, encoding="utf-8", xml_declaration=True)
    return SCENE_PATH, settings


if __name__ == "__main__":
    print(build_scene()[0])
