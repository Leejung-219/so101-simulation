"""Desktop SO-101 simulator with MuJoCo physics and wrist RGB."""

import argparse
import os
from pathlib import Path
import time

os.environ.setdefault("MUJOCO_GL", "egl")

import mujoco
import numpy as np
from PIL import Image, ImageTk
import tkinter as tk
from tkinter import ttk

from simulator import Simulation


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--duration", type=float, default=0)
    parser.add_argument("--capture-on-exit", action="store_true")
    parser.add_argument("--desktop-screenshot", type=Path)
    parser.add_argument("--check-controls", action="store_true")
    args = parser.parse_args()
    sim = Simulation()
    root = tk.Tk()
    root.title("SO-101 | MuJoCo")
    root.geometry("+80+60")
    root.resizable(False, False)
    main_panel = ttk.Frame(root, padding=10)
    main_panel.grid(row=0, column=0, sticky="n")
    control_panel = ttk.Frame(root, padding=10)
    control_panel.grid(row=0, column=1, sticky="n")
    ttk.Label(main_panel, text="SO-101").pack(anchor="w", pady=(0, 8))
    overview = ttk.Label(main_panel)
    overview.pack()
    ttk.Label(control_panel, text="Wrist RGB").pack(anchor="w", pady=(0, 8))
    preview = ttk.Label(control_panel)
    preview.pack()
    for label, size in [(overview, (800, 450)), (preview, (640, 360))]:
        photo = ImageTk.PhotoImage(Image.new("RGB", size, "#202424"))
        label.configure(image=photo)
        label.image = photo
    controls = ttk.Frame(control_panel, padding=(0, 8))
    controls.pack(fill="x")
    controls.columnconfigure(1, weight=1)
    paused = tk.BooleanVar(value=False)
    demo = tk.BooleanVar(value=args.demo)
    variables, readouts, sliders = [], [], []
    syncing = False
    running = True
    camera = mujoco.MjvCamera()
    camera.lookat[:] = [0.2, 0, 0.13]
    camera.distance = 0.85
    camera.azimuth = 135
    camera.elevation = -30
    drag_start = [0, 0]

    def close():
        nonlocal running
        running = False

    def change_target(_=None):
        if not syncing:
            demo.set(False)
            sim.set_targets(np.radians([var.get() for var in variables]))

    def reset():
        nonlocal syncing
        demo.set(False)
        sim.reset()
        syncing = True
        for var, value in zip(variables, np.degrees(sim.home)):
            var.set(value)
        syncing = False

    def capture():
        print(f"Saved: {sim.capture()}", flush=True)

    def start_drag(event):
        drag_start[:] = [event.x, event.y]

    def orbit(event):
        camera.azimuth -= (event.x - drag_start[0]) * 0.4
        camera.elevation = np.clip(camera.elevation - (event.y - drag_start[1]) * 0.4, -89, 0)
        start_drag(event)

    def zoom(factor):
        camera.distance = np.clip(camera.distance * factor, 0.15, 2.5)

    overview.bind("<ButtonPress-1>", start_drag)
    overview.bind("<B1-Motion>", orbit)
    overview.bind("<Button-4>", lambda _: zoom(0.9))
    overview.bind("<Button-5>", lambda _: zoom(1.1))
    root.protocol("WM_DELETE_WINDOW", close)
    root.bind("<Escape>", lambda _: close())
    root.bind("r", lambda _: reset())
    root.bind("s", lambda _: capture())
    root.bind("d", lambda _: demo.set(not demo.get()))
    root.bind("<space>", lambda _: paused.set(not paused.get()))

    labels = ["Shoulder pan", "Shoulder lift", "Elbow flex", "Wrist flex", "Wrist roll", "Gripper"]
    for i, name in enumerate(labels):
        ttk.Label(controls, text=name).grid(row=i, column=0, sticky="w", padx=(0, 10), pady=8)
        var = tk.DoubleVar(value=np.degrees(sim.home[i]))
        variables.append(var)
        limits = np.degrees(sim.limits[i])
        slider = ttk.Scale(controls, from_=limits[0], to=limits[1], variable=var, command=change_target)
        slider.grid(row=i, column=1, sticky="ew", pady=8)
        sliders.append(slider)
        label = ttk.Label(controls, width=17, anchor="e")
        label.grid(row=i, column=2, padx=(10, 0))
        readouts.append(label)
    toolbar = ttk.Frame(control_panel, padding=(0, 8))
    toolbar.pack(fill="x")
    ttk.Checkbutton(toolbar, text="Pause", variable=paused).pack(side="left", padx=5)
    ttk.Checkbutton(toolbar, text="Demo", variable=demo).pack(side="left", padx=5)
    ttk.Button(toolbar, text="Reset", command=reset).pack(side="left", padx=5)
    ttk.Button(toolbar, text="Capture RGB", command=capture).pack(side="left", padx=5)
    status = ttk.Label(main_panel, anchor="w", padding=(0, 10))
    status.pack(fill="x")
    root.update_idletasks()
    if args.check_controls:
        sliders[0].set(10.0)
        assert np.isclose(sim.data.ctrl[sim.actuator_ids[0]], np.radians(10))
        reset()
        assert np.allclose(sim.data.ctrl[sim.actuator_ids], sim.home)
        demo.set(args.demo)
        print("GUI slider and reset callbacks: PASS", flush=True)
    start = previous = time.monotonic()
    next_frame = start
    accumulator = 0.0
    frame_count = 0
    try:
        print("SO-101 ready. R: reset; S: capture; D: demo; Space: pause; Esc: close.", flush=True)
        while running:
            now = time.monotonic()
            if args.duration and now - start >= args.duration:
                break
            root.update_idletasks()
            root.update()
            elapsed = min(now - previous, 0.2)
            previous = now
            if not paused.get():
                accumulator += elapsed
                steps = min(int(accumulator / sim.model.opt.timestep), 100)
                if steps:
                    if demo.get():
                        sim.set_targets(sim.demo_targets(sim.data.time))
                    sim.step(steps)
                    accumulator -= steps * sim.model.opt.timestep
            else:
                accumulator = 0
            if now >= next_frame:
                for label, view, size in [(overview, camera, (800, 450)), (preview, "wrist_rgb", (640, 360))]:
                    rgb = sim.rgb(view, preview=True)
                    image = Image.fromarray(rgb).resize(size, Image.Resampling.BILINEAR)
                    photo = ImageTk.PhotoImage(image)
                    label.configure(image=photo)
                    label.image = photo
                targets = np.degrees(sim.data.ctrl[sim.actuator_ids])
                actual = np.degrees(sim.data.qpos[sim.qpos_ids])
                syncing = True
                for i, label in enumerate(readouts):
                    label.configure(text=f"{actual[i]:6.1f} / {targets[i]:6.1f} deg")
                    if demo.get():
                        variables[i].set(targets[i])
                syncing = False
                frame_count += 1
                rate = frame_count / max(now - start, 0.001)
                spec = sim.settings["camera"]
                status.configure(text=f"t = {sim.data.time:.2f} s   |   Preview {rate:.1f} fps   |   Capture {spec['width']} x {spec['height']}")
                next_frame = now + 1 / sim.settings["preview_fps"]
            time.sleep(0.001)
        if args.capture_on_exit:
            capture()
        if args.desktop_screenshot:
            from PIL import ImageGrab
            root.update_idletasks()
            x, y = root.winfo_rootx(), root.winfo_rooty()
            args.desktop_screenshot.parent.mkdir(parents=True, exist_ok=True)
            ImageGrab.grab(bbox=(x, y, x + root.winfo_width(), y + root.winfo_height())).save(args.desktop_screenshot)
        print(f"Frames: {frame_count}; simulation time: {sim.data.time:.3f}s", flush=True)
    finally:
        sim.close()
        root.destroy()
    print("Stopped cleanly.", flush=True)


if __name__ == "__main__":
    main()
