"""Check physics, joint control, wrist attachment and actual rendered RGB."""

import json
import os

os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("LIBGL_ALWAYS_SOFTWARE", "1")

import mujoco
import numpy as np
from PIL import Image

from build_scene import ROOT
from simulator import Simulation


def main():
    sim = Simulation()
    try:
        assert sim.model.nu == 6
        assert sim.model.camera("wrist_rgb").bodyid == sim.model.body("wrist_camera").id
        sim.step(500)
        initial = sim.data.qpos[sim.qpos_ids].copy()
        camera_start = sim.data.camera("wrist_rgb").xpos.copy()
        image_start = sim.rgb()
        output = ROOT / "captures/verification"
        sim.capture(output)
        targets = sim.home.copy()
        targets[0] += 0.2
        targets[4] += 0.15
        targets[5] += 0.2
        sim.set_targets(targets)
        sim.step(1000)
        image_end = sim.rgb()
        assert image_end.shape == (720, 1280, 3)
        assert image_end.std() > 10, "Camera image is blank."
        pixel_change = float(np.abs(image_end.astype(float) - image_start).mean())
        assert pixel_change > 1, "Wrist image did not change after motion."
        displacement = float(np.linalg.norm(sim.data.camera("wrist_rgb").xpos - camera_start))
        assert displacement > 0.005, "Camera did not move with the wrist."
        joint_motion = sim.data.qpos[sim.qpos_ids] - initial
        assert abs(joint_motion[0]) > 0.1, "Shoulder motor failed to move."
        assert abs(joint_motion[5]) > 0.1, "Gripper motor failed to move."
        assert np.isfinite(sim.data.qpos).all() and np.isfinite(sim.data.qvel).all()
        tracking_error = float(np.max(np.abs(sim.data.qpos[sim.qpos_ids] - targets)))
        assert tracking_error < 0.08, f"Excessive position error: {tracking_error} rad"
        assert sum(w.number for w in sim.data.warning) == 0, "MuJoCo raised a simulation warning."
        Image.fromarray(image_end).save(output / "wrist_after_motion.png")
        report = {
            "mujoco_version": mujoco.__version__,
            "actuators": sim.model.nu,
            "cameras": sim.model.ncam,
            "rgb_shape": list(image_end.shape),
            "rgb_std": float(image_end.std()),
            "mean_pixel_change_after_motion": pixel_change,
            "wrist_camera_displacement_m": displacement,
            "max_tracking_error_rad": tracking_error,
            "simulated_seconds": sim.data.time,
            "warnings": 0,
        }
        sim.reset()
        assert np.allclose(sim.data.qpos[sim.qpos_ids], sim.home)
        assert sim.data.time == 0
        report["reset_passed"] = True
        (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps(report, indent=2))
    finally:
        sim.close()


if __name__ == "__main__":
    main()
