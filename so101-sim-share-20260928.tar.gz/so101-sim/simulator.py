"""MuJoCo simulation and RGB capture, with no hardware connection."""

import json
from datetime import datetime

import mujoco
import numpy as np
from PIL import Image

from build_scene import ROOT, build_scene


class Simulation:
    def __init__(self):
        path, self.settings = build_scene()
        self.model = mujoco.MjModel.from_xml_path(str(path))
        self.data = mujoco.MjData(self.model)
        self.joints = list(self.settings["home_rad"])
        self.actuator_ids = np.array([self.model.actuator(name).id for name in self.joints])
        self.qpos_ids = np.array([self.model.joint(name).qposadr[0] for name in self.joints])
        self.home = np.array([self.settings["home_rad"][name] for name in self.joints])
        self.limits = self.model.actuator_ctrlrange[self.actuator_ids].copy()
        self.render_options = mujoco.MjvOption()
        self.render_options.geomgroup[3] = 0
        self.renderer = None
        self.preview_renderer = None
        self.reset()

    def reset(self):
        mujoco.mj_resetData(self.model, self.data)
        self.data.qpos[self.qpos_ids] = self.home
        self.set_targets(self.home)
        mujoco.mj_forward(self.model, self.data)

    def set_targets(self, radians):
        values = np.asarray(radians, dtype=float)
        if values.shape != self.home.shape or not np.isfinite(values).all():
            raise ValueError("Expected six finite joint targets, in radians.")
        self.data.ctrl[self.actuator_ids] = np.clip(values, self.limits[:, 0], self.limits[:, 1])

    def step(self, count=1):
        mujoco.mj_step(self.model, self.data, nstep=count)
        mujoco.mj_forward(self.model, self.data)

    def demo_targets(self, elapsed):
        targets = self.home.copy()
        targets[0] += 0.22 * np.sin(elapsed * 0.7)
        targets[4] += 0.2 * np.sin(elapsed * 0.9)
        targets[5] = 0.65 + 0.3 * np.sin(elapsed * 1.1)
        return targets

    def rgb(self, camera=None, preview=False):
        spec = self.settings["camera"]
        if preview:
            if self.preview_renderer is None:
                height = round(640 * spec["height"] / spec["width"])
                self.preview_renderer = mujoco.Renderer(self.model, height=height, width=640)
            renderer = self.preview_renderer
        else:
            if self.renderer is None:
                self.renderer = mujoco.Renderer(self.model, height=spec["height"], width=spec["width"])
            renderer = self.renderer
        renderer.update_scene(self.data, camera=camera or spec["name"], scene_option=self.render_options)
        if preview:
            renderer.scene.flags[mujoco.mjtRndFlag.mjRND_SHADOW] = False
        return renderer.render().copy()

    def capture(self, directory=None):
        directory = directory or ROOT / "captures" / datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        directory.mkdir(parents=True, exist_ok=True)
        for camera in ["overview", self.settings["camera"]["name"]]:
            Image.fromarray(self.rgb(camera)).save(directory / f"{camera}.png")
        state = {
            "simulation_time_s": self.data.time,
            "joint_positions_rad": dict(zip(self.joints, self.data.qpos[self.qpos_ids].tolist())),
            "joint_targets_rad": dict(zip(self.joints, self.data.ctrl[self.actuator_ids].tolist())),
            "camera": self.settings["camera"],
            "upstream_commit": self.settings["upstream_commit"],
        }
        (directory / "state.json").write_text(json.dumps(state, indent=2) + "\n")
        return directory

    def close(self):
        if self.preview_renderer is not None:
            self.preview_renderer.close()
            self.preview_renderer = None
        if self.renderer is not None:
            self.renderer.close()
            self.renderer = None
