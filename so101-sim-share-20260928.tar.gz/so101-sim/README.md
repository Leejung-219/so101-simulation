# SO-101 MuJoCo 실습 환경

공식 SO-101 모델을 사용한 로컬 시뮬레이션입니다. 실제 로봇이나 USB 카메라에 연결하지 않습니다.

## 실행

```bash
cd /home/leesangjung/다운로드/so101-sim
./run.sh
```

설치된 `.venv`를 실행 스크립트가 직접 사용하므로 가상환경 활성화는 필요하지 않습니다.
현재 PC의 NVIDIA 드라이버를 설치하거나 변경하지 않았습니다.
Mesa 소프트웨어 렌더링으로 실행하며 기존 ROS의 `PYTHONPATH`는 이 프로세스에서만 제외합니다.

자동 동작으로 시작하려면:

```bash
./run.sh --demo
```

## 화면과 조작

- 왼쪽: 로봇 전체 화면. 마우스 왼쪽 드래그로 회전, 휠로 확대/축소.
- 오른쪽: 로봇 손목에 고정된 가상 RGB 카메라 영상.
- 관절 슬라이더: 팔 5개 관절과 집게 1개를 조작합니다. 단위는 도(degree)입니다.
- 각 관절의 숫자는 `현재 각도 / 목표 각도`입니다.
- `Pause`: 물리 시뮬레이션 일시정지.
- `Demo`: 밑동, 손목 회전, 집게를 움직이는 단순 동작. 집기 정책이 아닙니다.
- `Reset`: 관절과 블록을 초기 상태로 되돌립니다.
- `Capture RGB`: 전체 화면과 손목 카메라의 PNG 및 관절 상태 JSON을 저장합니다.
- 단축키: `R` 초기화, `S` 저장, `D` 자동 동작, `Space` 일시정지, `Esc` 종료.

저장 경로: `captures/<날짜-시간>/`. 저장된 `overview.png`는 관찰용 시점이지,
대회에서 제공되는 두 번째 카메라를 가정한 것이 아닙니다.

## 카메라 설정과 한계

`settings.json`에서 변경한 설정은 다음 실행 시 적용됩니다.

| 항목 | 현재 설정 |
| --- | --- |
| 모형과 마운트 위치 | 공식 `so101_new_calib_camera.xml`의 손목 카메라 배치 유지 |
| 가상 렌즈 위치 | `wrist_camera` 로컬 좌표 `[0, 0, 0.0265]` m |
| 촬영 방향 | 모형의 로컬 +Z축; 영상 위쪽은 로컬 +X축 |
| 저장 해상도 | 1280 x 720 |
| 화각 | 수평 72도로 임시 가정, MuJoCo 수직 화각으로 변환 |
| 미리보기 | 640 x 360 렌더링, 최대 15fps 목표 |
| 현재 PC 실행 검증 | 자동 동작 시 약 10fps. 부하에 따라 달라짐 |

원본 카메라 STL의 렌즈 앞면은 로컬 Z 약 26.3mm에 있습니다. 가상 시점은
그 바로 앞 26.5mm에 배치했습니다. 광학 중심 실측값은 아니며 실물 보정이 필요합니다.
`fov_axis`는 `horizontal`, `vertical`, `diagonal` 중 선택할 수 있습니다.
주신 72도 사양의 기준이 확인되면 이를 수정해야 합니다.

`camera.fps: 30`은 제공 카메라의 목표 사양을 기록한 값입니다. 현재 프로그램이
30fps 영상 녹화나 실시간 처리를 보장한다는 의미가 아닙니다. 지금은 미리보기와
단일 프레임 저장을 제공하며 연속 영상 녹화 기능은 포함하지 않았습니다.

이 가상 카메라는 핀홀 RGB 렌더링입니다. MJPEG 압축, 노출, 초점 흐림,
렌즈 왜곡, 센서 지연을 재현하지 않습니다. 기본 출력에 깊이 영상은 없습니다.
카메라 모형은 32 x 32 UVC 모듈 기준이며 대회 카메라와 동일하다고 확정하지 않았습니다.

## 로봇과 장면

- 공식 모델의 관절, 질량, 구동기 설정을 사용합니다. 실물의 검증된 출력 사양은 아닙니다.
- 로컬 장면에 작업 바닥과 3cm 크기의 물리 블록 3개를 추가했습니다.
- 블록, 바닥, 초기 자세는 실습용이며 대회 경기장을 재현한 것이 아닙니다.
- 집게 접촉의 정확도, 실제 물체 집기 성공률, 모방학습·강화학습은 아직 검증하지 않았습니다.
- Python API는 라디안을 사용합니다. LeRobot의 도/정규화 값과 연결하는 변환은 별도 작업입니다.

## 검증

```bash
env -u PYTHONPATH .venv/bin/python verify.py
```

물리 엔진 3초 실행, 구동기 6개, 카메라의 손목 추종, 관절 목표 추종,
1280 x 720 RGB 이미지 생성, 이동 전후 이미지 변화, 초기화를 검사합니다.
결과와 이미지는 `captures/verification/`에 저장됩니다.

GUI 검증은 데스크톱 세션에서 실행합니다.

```bash
./run.sh --demo --check-controls --duration 6 --capture-on-exit
```

검증 당시 MuJoCo 경고 0건, 최종 관절 목표 오차 최대 약 0.00045rad,
손목 카메라 이동 약 4.1cm를 확인했습니다. 이는 해당 시험 동작의 결과입니다.

## 파일 구성

| 경로 | 역할 |
| --- | --- |
| `vendor/SO-ARM100/` | 수정하지 않은 공식 Git 저장소의 sparse checkout |
| `settings.json` | 카메라, 초기 자세, 미리보기 주기 |
| `build_scene.py` | 원본 XML을 읽어 로컬 장면 생성 |
| `generated/scene.xml` | 실행 시 재생성되는 MuJoCo 장면 |
| `simulator.py` | 물리 실행, 관절 명령, RGB 출력 API |
| `run.py`, `run.sh` | 데스크톱 실행 화면과 런처 |
| `verify.py` | 물리·영상 검증 |
| `requirements.txt` | 설치한 직접 의존성 버전 |

## 원본과 설치 기록

- 원본: https://github.com/TheRobotStudio/SO-ARM100
- 체크아웃 커밋: `5f6d2b876a53a4872e405b991dd925556c9e38a4`
- 모델: `Simulation/SO101/so101_new_calib_camera.xml`
- 환경: Python 3.10.12, MuJoCo 3.14.0, NumPy 2.2.6, Pillow 12.3.0
- MuJoCo 문서: https://mujoco.readthedocs.io/en/stable/python.html
- 원본 라이선스는 `vendor/SO-ARM100/LICENSE`를 참고하세요.

현재 가상환경에는 필요한 패키지가 설치되어 있습니다. 다른 PC에서 재구축할 때는
원본 저장소의 위 커밋과 `Simulation/SO101` 폴더를 확보하고, Python 가상환경에
`python -m pip install -r requirements.txt`로 설치합니다. GUI에는 Tkinter와
데스크톱 세션이, 렌더링에는 EGL을 지원하는 OpenGL/Mesa 환경이 필요합니다.
